
package deti.ir.ranking;

/**
 * Universidade de Aveiro, DETI, Recuperação de Informação 
 * @author Gabriel Vieira, gabriel.vieira@ua.pt
 * @author Rui Oliveira, ruipedrooliveira@ua.pt
 */
public class Ranker {
    
    public Ranker(){
        
    }
    
    public void orderResults(){
        
    }
    
}
