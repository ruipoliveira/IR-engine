package deti.ir;

/**
 * Universidade de Aveiro, DETI, Recuperação de Informação 
 * @author Gabriel Vieira, gabriel.vieira@ua.pt
 * @author Rui Oliveira, ruipedrooliveira@ua.pt
 */
public class RIproject {
    private DocumentProcessor dp; 
    private SearcherProcessor sp; 
    
    public static void main(String[]args){
        System.out.println("Test main"); 
    }
    
}
