package deti.ir.searcher;

import java.util.List;

/**
 * Universidade de Aveiro, DETI, Recuperação de Informação 
 * @author Gabriel Vieira, gabriel.vieira@ua.pt
 * @author Rui Oliveira, ruipedrooliveira@ua.pt
 */
public class Searcher {
    public Searcher(){
        
    }
    
    public List<String> getTerms(){
        return null;
    }
}
