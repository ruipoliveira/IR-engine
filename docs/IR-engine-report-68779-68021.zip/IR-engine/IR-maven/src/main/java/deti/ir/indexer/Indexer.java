package deti.ir.indexer;

/**
 * Universidade de Aveiro, DETI, Recuperação de Informação 
 * @author Gabriel Vieira, gabriel.vieira@ua.pt
 * @author Rui Oliveira, ruipedrooliveira@ua.pt
 */
public class Indexer {
    public Indexer(){
        
    }
    
    public void addTerm(){
        
    }
}
